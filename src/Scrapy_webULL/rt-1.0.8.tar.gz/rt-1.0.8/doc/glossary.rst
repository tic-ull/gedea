Glossary
========

.. glossary::
    :sorted:

    API
        An application programming interface, a source code based specification
        intended to be used as an interface by software components to
        communicate with each other.

    REST
        Representational state transfer,  a style of software architecture for
        distributed hypermedia systems such as the World Wide Web

